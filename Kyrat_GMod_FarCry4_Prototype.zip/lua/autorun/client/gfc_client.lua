local BRIDGE = "http://127.0.0.1:27841"
local state = {
    detected = false,
    path = "",
    running = false,
    message = "Bridge not checked"
}

local function set_state(data)
    state.detected = data.detected == true
    state.running = data.running == true
    state.path = tostring(data.path or "")
    state.message = tostring(data.message or "")
end

local function poll_bridge()
    http.Fetch(BRIDGE .. "/status", function(body)
        local ok, data = pcall(util.JSONToTable, body)
        if ok and istable(data) then
            set_state(data)
        else
            state.message = "Invalid bridge response"
        end
    end, function(err)
        state.message = "Bridge unavailable: " .. tostring(err)
        state.detected = false
        state.running = false
    end)
end

timer.Create("GFCBridgePoll", 3, 0, poll_bridge)
poll_bridge()

net.Receive("gfc_portal_request", function()
    http.Post(BRIDGE .. "/portal", {
        source = "garrysmod",
        action = "open_farcry4"
    }, function(body)
        local ok, data = pcall(util.JSONToTable, body)
        if ok and istable(data) then
            set_state(data)
        end
    end, function(err)
        state.message = "Portal request failed: " .. tostring(err)
    end)
end)

hook.Add("HUDPaint", "GFCHud", function()
    local x, y = ScrW() - 390, 28
    draw.RoundedBox(8, x, y, 360, 92, Color(8, 10, 14, 220))
    draw.SimpleText("KYRAT SANDBOX BRIDGE", "Trebuchet24", x + 14, y + 10, Color(240, 240, 240))

    local companion = "Far Cry 4: " .. (state.detected and "detected" or "not detected")
    draw.SimpleText(companion, "Trebuchet18", x + 14, y + 38, Color(220, 220, 220))

    local run = state.running and "running" or "stopped"
    draw.SimpleText("Companion: " .. run, "Trebuchet18", x + 14, y + 60, Color(220, 220, 220))
end)
