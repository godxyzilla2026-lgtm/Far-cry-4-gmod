if SERVER then
    AddCSLuaFile("autorun/client/gfc_client.lua")
    AddCSLuaFile("entities/gfc_portal/shared.lua")
    AddCSLuaFile("entities/gfc_portal/cl_init.lua")

    util.AddNetworkString("gfc_portal_request")

    hook.Add("PlayerInitialSpawn", "GFCSpawnPortal", function(ply)
        timer.Simple(2, function()
            if not IsValid(ply) then return end
            if ply.GFCSpawnedPortal then return end

            local pos = ply:GetPos() + ply:GetForward() * 120 + Vector(0, 0, 16)
            local ent = ents.Create("gfc_portal")
            if not IsValid(ent) then return end

            ent:SetPos(pos)
            ent:SetAngles(Angle(0, ply:EyeAngles().y, 0))
            ent:Spawn()
            ent:SetOwner(ply)
            ply.GFCSpawnedPortal = ent
        end)
    end)

    net.Receive("gfc_portal_request", function(_, ply)
        if not IsValid(ply) then return end
        net.Start("gfc_portal_request")
        net.Send(ply)
    end)
end

if SERVER then
    local function ground_position(ply, distance)
        local origin = ply:GetPos() + ply:GetForward() * distance + Vector(0, 0, 180)
        local trace = util.TraceLine({
            start = origin,
            endpos = origin - Vector(0, 0, 500),
            filter = ply
        })
        return trace.Hit and (trace.HitPos + Vector(0, 0, 18)) or (ply:GetPos() + ply:GetForward() * distance)
    end

    hook.Add("PlayerInitialSpawn", "GFCSpawnObjectives", function(ply)
        timer.Simple(2.2, function()
            if not IsValid(ply) then return end
            if ply.GFCSpawnedObjectives then return end

            local definitions = {
                { kind = "outpost", distance = 420 },
                { kind = "fortress", distance = 720 }
            }

            for _, def in ipairs(definitions) do
                local ent = ents.Create("gfc_objective")
                if not IsValid(ent) then continue end
                ent:SetPos(ground_position(ply, def.distance))
                ent:SetObjectiveKind(def.kind)
                ent:Spawn()
            end
            ply.GFCSpawnedObjectives = true
        end)
    end)
end
