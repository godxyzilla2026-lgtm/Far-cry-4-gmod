include("shared.lua")

function ENT:Draw()
    local completed = self:GetNWBool("GFCCompleted", false)
    local kind = self:GetObjectiveKind()
    local label = kind == "fortress" and "FORTRESS" or "OUTPOST"
    local base = self:GetPos() + Vector(0, 0, 24)

    render.SetColorMaterial()
    render.DrawSphere(base, 20, 16, 16, completed and Color(110, 220, 140, 70) or Color(240, 190, 90, 70))
    self:DrawModel()

    cam.Start3D2D(base + Vector(0, 0, 28), Angle(0, EyeAngles().y - 90, 90), 0.12)
        draw.SimpleText(completed and (label .. " COMPLETE") or label, "Trebuchet24", 0, 0,
            Color(240, 240, 240), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText(completed and "Objective complete" or "Press USE", "Trebuchet18", 0, 26,
            Color(220, 220, 220), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    cam.End3D2D()
end
