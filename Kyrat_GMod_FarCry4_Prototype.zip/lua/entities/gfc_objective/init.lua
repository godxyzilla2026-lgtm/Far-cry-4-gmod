AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

function ENT:Initialize()
    self:SetModel("models/hunter/blocks/cube025x025x025.mdl")
    self:SetMoveType(MOVETYPE_NONE)
    self:SetSolid(SOLID_VPHYSICS)
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE)
    self:SetMaterial("models/debug/debugwhite")
end

function ENT:Use(activator)
    if not IsValid(activator) or not activator:IsPlayer() then return end
    if self:GetNWBool("GFCCompleted", false) then return end

    self:SetNWBool("GFCCompleted", true)
    local label = self:GetObjectiveKind() == "fortress" and "Fortress secured" or "Outpost secured"
    PrintMessage(HUD_PRINTCENTER, label)
end
