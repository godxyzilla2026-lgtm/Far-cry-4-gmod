ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Kyrat Objective"
ENT.Category = "Kyrat Sandbox"
ENT.Spawnable = false
ENT.AdminOnly = false

function ENT:SetObjectiveKind(kind)
    self:SetNWString("GFCObjectiveKind", kind)
end

function ENT:GetObjectiveKind()
    return self:GetNWString("GFCObjectiveKind", "outpost")
end
