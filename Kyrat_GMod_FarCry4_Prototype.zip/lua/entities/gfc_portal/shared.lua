ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Kyrat Portal"
ENT.Category = "Kyrat Sandbox"
ENT.Spawnable = false
ENT.AdminOnly = false
