include("shared.lua")

function ENT:Draw()
    self:DrawModel()
    render.SetColorMaterial()
    local glow = 70 + math.sin(CurTime() * 3) * 12
    render.DrawSphere(self:GetPos() + Vector(0, 0, 18), glow, 16, 16, Color(120, 180, 255, 35))
end
