AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

function ENT:Initialize()
    self:SetModel("models/props_lab/teleport.mdl")
    self:SetMoveType(MOVETYPE_NONE)
    self:SetSolid(SOLID_VPHYSICS)
    self:PhysicsInit(SOLID_VPHYSICS)
end

function ENT:Use(activator)
    if not IsValid(activator) or not activator:IsPlayer() then return end
    net.Start("gfc_portal_request")
    net.Send(activator)
end
