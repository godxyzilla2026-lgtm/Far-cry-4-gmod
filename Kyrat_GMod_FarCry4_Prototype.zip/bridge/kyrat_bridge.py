from __future__ import annotations

import json
import os
import re
import subprocess
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

PORT = 27841
FARCRY_APPID = "298110"


def steam_roots() -> list[Path]:
    roots: list[Path] = []
    candidates = []
    for env_name in ("PROGRAMFILES(X86)", "PROGRAMFILES", "LOCALAPPDATA"):
        value = os.environ.get(env_name)
        if value:
            candidates.append(Path(value) / "Steam")
    for c in candidates:
        if c.exists():
            roots.append(c)
    return roots


def parse_libraryfolders(vdf: Path) -> list[Path]:
    try:
        raw = vdf.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return []
    paths = []
    for match in re.finditer(r'"path"\s+"([^"]+)"', raw):
        paths.append(Path(match.group(1).replace("\\\\", "\\")))
    return paths


def find_farcry4() -> Path | None:
    for steam in steam_roots():
        manifest = steam / "steamapps" / f"appmanifest_{FARCRY_APPID}.acf"
        if manifest.exists():
            try:
                raw = manifest.read_text(encoding="utf-8", errors="ignore")
                m = re.search(r'"installdir"\s+"([^"]+)"', raw)
                if m:
                    p = steam / "steamapps" / "common" / m.group(1)
                    if p.exists():
                        return p
            except OSError:
                pass

        libs = parse_libraryfolders(steam / "steamapps" / "libraryfolders.vdf")
        for lib in [steam] + libs:
            manifest = lib / "steamapps" / f"appmanifest_{FARCRY_APPID}.acf"
            if not manifest.exists():
                continue
            try:
                raw = manifest.read_text(encoding="utf-8", errors="ignore")
                m = re.search(r'"installdir"\s+"([^"]+)"', raw)
                if m:
                    p = lib / "steamapps" / "common" / m.group(1)
                    if p.exists():
                        return p
            except OSError:
                pass
    return None


class BridgeState:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.path = find_farcry4()
        self.running = False

    def refresh(self) -> None:
        with self.lock:
            self.path = find_farcry4()

    def payload(self, message: str = "") -> dict[str, Any]:
        with self.lock:
            return {
                "detected": self.path is not None,
                "path": str(self.path or ""),
                "running": self.running,
                "message": message or ("Far Cry 4 detected" if self.path else "Far Cry 4 not detected"),
            }

    def launch(self) -> dict[str, Any]:
        self.refresh()
        if self.path is None:
            return self.payload("Far Cry 4 was not found in the Steam libraries")
        try:
            # Launches the player's own Steam copy; no game files are copied by this bridge.
            subprocess.Popen(["cmd", "/c", "start", "", f"steam://rungameid/{FARCRY_APPID}"],
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            with self.lock:
                self.running = True
            return self.payload("Far Cry 4 launch requested")
        except Exception as exc:
            return self.payload(f"Launch request failed: {exc}")


STATE = BridgeState()


class Handler(BaseHTTPRequestHandler):
    def _write(self, payload: dict[str, Any]) -> None:
        data = json.dumps(payload).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:
        if self.path == "/status":
            STATE.refresh()
            self._write(STATE.payload())
            return
        self.send_error(404)

    def do_POST(self) -> None:
        if self.path != "/portal":
            self.send_error(404)
            return
        length = int(self.headers.get("Content-Length", "0"))
        if length:
            self.rfile.read(length)
        self._write(STATE.launch())

    def log_message(self, fmt: str, *args: Any) -> None:
        print(fmt % args)


if __name__ == "__main__":
    print(f"Kyrat bridge listening on http://127.0.0.1:{PORT}")
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
